/*
**	Command & Conquer Renegade(tm)
**	Copyright 2025 Electronic Arts Inc.
**
**	This program is free software: you can redistribute it and/or modify
**	it under the terms of the GNU General Public License as published by
**	the Free Software Foundation, either version 3 of the License, or
**	(at your option) any later version.
**
**	This program is distributed in the hope that it will be useful,
**	but WITHOUT ANY WARRANTY; without even the implied warranty of
**	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**	GNU General Public License for more details.
**
**	You should have received a copy of the GNU General Public License
**	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once

// CameraSettingsDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CameraSettingsDialogClass dialog

class CameraSettingsDialogClass : public CDialog
{
// Construction
public:
	CameraSettingsDialogClass(CWnd* pParent = nullptr);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CameraSettingsDialogClass)
	enum { IDD = IDD_CAMERA_SETTINGS };
	CSpinButtonCtrl	m_LensSpin;
	CSpinButtonCtrl	m_FarClipSpin;
	CSpinButtonCtrl	m_VFOVSpin;
	CSpinButtonCtrl	m_NearClipSpin;
	CSpinButtonCtrl	m_HFOVSpin;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CameraSettingsDialogClass)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX) override;    // DDX/DDV support
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) override;
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam) override;
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CameraSettingsDialogClass)
	virtual BOOL OnInitDialog() override;
	virtual void OnOK() override;
	afx_msg void OnFovCheck();
	afx_msg void OnClipPlaneCheck();
	afx_msg void OnReset();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:

	///////////////////////////////////////////////////////////////////
	//	Protected methods
	///////////////////////////////////////////////////////////////////
	void			Update_Camera_Lens ();
	void			Update_FOV ();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
