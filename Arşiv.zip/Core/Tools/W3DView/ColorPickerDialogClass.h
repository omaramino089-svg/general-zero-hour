/*
**	Command & Conquer Renegade(tm)
**	Copyright 2025 Electronic Arts Inc.
**
**	This program is free software: you can redistribute it and/or modify
**	it under the terms of the GNU General Public License as published by
**	the Free Software Foundation, either version 3 of the License, or
**	(at your option) any later version.
**
**	This program is distributed in the hope that it will be useful,
**	but WITHOUT ANY WARRANTY; without even the implied warranty of
**	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**	GNU General Public License for more details.
**
**	You should have received a copy of the GNU General Public License
**	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once

// ColorPickerDialogClass.h : header file
//

#include "resource.h"
#include "ColorUtils.h"


/////////////////////////////////////////////////////////////////////////////
// Forward declarations
/////////////////////////////////////////////////////////////////////////////
class ColorBarClass;
class ColorPickerClass;

/////////////////////////////////////////////////////////////////////////////
//
// ColorPickerDialogClass dialog
//
class ColorPickerDialogClass : public CDialog
{
// Construction
public:
	ColorPickerDialogClass (int red, int green, int blue, CWnd* pParent = nullptr, UINT res_id = ColorPickerDialogClass::IDD);

// Dialog Data
	//{{AFX_DATA(ColorPickerDialogClass)
	enum { IDD = IDD_COLOR_PICKER };
	CSpinButtonCtrl	m_BlueSpin;
	CSpinButtonCtrl	m_GreenSpin;
	CSpinButtonCtrl	m_RedSpin;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ColorPickerDialogClass)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX)  override;    // DDX/DDV support
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) override;
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam) override;
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam) override;
	virtual void PostNcDestroy() override;
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ColorPickerDialogClass)
	virtual BOOL OnInitDialog() override;
	afx_msg void OnReset();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	public:

		/////////////////////////////////////////////////////////////
		//	Public methods
		/////////////////////////////////////////////////////////////
		int					Get_Red () const { return (int)m_CurrentRed; }
		int					Get_Green () const { return (int)m_CurrentGreen; }
		int					Get_Blue () const { return (int)m_CurrentBlue; }
		void					Set_Color (int r, int g, int b)
									{ Update_Color((float)r, (float)g, (float)b); }
		void					Set_Original_Color (int r, int g, int b);
		void					Create_Form (CWnd *parent);
		void					Set_Update_Callback (WWCTRL_COLORCALLBACK callme, void *arg)
									{ m_UpdateCallback = callme; m_CallArg = arg; }

	protected:

		/////////////////////////////////////////////////////////////
		//	Protected methods
		/////////////////////////////////////////////////////////////
		void					Update_Red_Bar ();
		void					Update_Green_Bar ();
		void					Update_Blue_Bar ();
		void					Update_Current_Color_Bar ();
		void					Update_Whiteness_Bar ();
		void					Update_Color (float red, float green, float blue, DWORD flags = 0xFFFFFFFF);

	private:

		/////////////////////////////////////////////////////////////
		//	Private member data
		/////////////////////////////////////////////////////////////
		float	m_OrigRed;
		float	m_OrigGreen;
		float	m_OrigBlue;

		float	m_CurrentRed;
		float	m_CurrentGreen;
		float	m_CurrentBlue;

		ColorBarClass *	m_CurrentColorBar;
		ColorBarClass *	m_OrigColorBar;
		ColorBarClass *	m_RedColorBar;
		ColorBarClass *	m_GreenColorBar;
		ColorBarClass *	m_BlueColorBar;
		ColorBarClass *	m_WhitenessColorBar;
		ColorPickerClass *m_HuePicker;

		bool	m_bDeleteOnClose;

		// Callback function when color is updated.
		WWCTRL_COLORCALLBACK m_UpdateCallback;
		void *					m_CallArg;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.
