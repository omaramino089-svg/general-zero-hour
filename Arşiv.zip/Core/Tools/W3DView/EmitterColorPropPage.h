/*
**	Command & Conquer Renegade(tm)
**	Copyright 2025 Electronic Arts Inc.
**
**	This program is free software: you can redistribute it and/or modify
**	it under the terms of the GNU General Public License as published by
**	the Free Software Foundation, either version 3 of the License, or
**	(at your option) any later version.
**
**	This program is distributed in the hope that it will be useful,
**	but WITHOUT ANY WARRANTY; without even the implied warranty of
**	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**	GNU General Public License for more details.
**
**	You should have received a copy of the GNU General Public License
**	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once

// EmitterColorPropPage.h : header file
//

#include "resource.h"
#include "vector3.h"
#include "ColorBar.h"
#include "part_emt.h"

// Forward declarations
class EmitterInstanceListClass;

/////////////////////////////////////////////////////////////////////////////
// EmitterColorPropPageClass dialog

class EmitterColorPropPageClass : public CPropertyPage
{
	DECLARE_DYNCREATE(EmitterColorPropPageClass)

// Construction
public:
	EmitterColorPropPageClass (EmitterInstanceListClass *pemitter_list = nullptr);
	~EmitterColorPropPageClass ();

// Dialog Data
	//{{AFX_DATA(EmitterColorPropPageClass)
	enum { IDD = IDD_PROP_PAGE_EMITTER_COLOR };
	CSpinButtonCtrl	m_OpacityRandomSpin;
	CSpinButtonCtrl	m_RedRandomSpin;
	CSpinButtonCtrl	m_GreenRandomSpin;
	CSpinButtonCtrl	m_BlueRandomSpin;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(EmitterColorPropPageClass)
	public:
	virtual BOOL OnApply() override;
	virtual void OnCancel() override;
	protected:
	virtual void DoDataExchange(CDataExchange* pDX) override;    // DDX/DDV support
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) override;
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam) override;
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(EmitterColorPropPageClass)
	virtual BOOL OnInitDialog() override;
	afx_msg void OnDestroy();
	afx_msg void OnDeltaposRedRandomSpin(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	public:

		/////////////////////////////////////////////////////////
		//
		//	Public methods
		//

		//
		//	Inline accessors
		//
		EmitterInstanceListClass *	Get_Emitter () const { return m_pEmitterList; }
		void								Set_Emitter (EmitterInstanceListClass *pemitter_list) { m_pEmitterList = pemitter_list; Initialize (); }
		bool								Is_Data_Valid () const { return m_bValid; }

		void								Get_Color_Keyframes (ParticlePropertyStruct<Vector3> &colors)	{ colors = m_CurrentColors; }
		void								Get_Opacity_Keyframes (ParticlePropertyStruct<float> &opacity)	{ opacity = m_CurrentOpacities; }
		/*const Vector3 &				Get_Start_Color () const { return m_StartColor; }
		const Vector3 &				Get_End_Color () const { return m_EndColor; }
		float								Get_Start_Opacity () const { return m_StartOpacity; }
		float								Get_End_Opacity () const { return m_EndOpacity; }
		float								Get_Fade_Time () const { return m_FadeTime; }*/

		void								On_Lifetime_Changed (float lifetime);

	protected:

		/////////////////////////////////////////////////////////
		//
		//	Protected methods
		//
		void				Initialize ();
		void				Update_Colors ();
		void				Update_Opacities ();

	private:

		/////////////////////////////////////////////////////////
		//
		//	Private member data
		//
		EmitterInstanceListClass *	m_pEmitterList;
		bool								m_bValid;
		ColorBarClass *				m_ColorBar;
		ColorBarClass *				m_OpacityBar;
		ParticlePropertyStruct<Vector3>	m_OrigColors;
		ParticlePropertyStruct<float>		m_OrigOpacities;
		ParticlePropertyStruct<Vector3>	m_CurrentColors;
		ParticlePropertyStruct<float>		m_CurrentOpacities;
		float								m_Lifetime;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
