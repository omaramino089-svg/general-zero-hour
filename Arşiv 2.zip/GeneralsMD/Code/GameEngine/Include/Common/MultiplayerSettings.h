/*
**	Command & Conquer Generals Zero Hour(tm)
**	Copyright 2025 Electronic Arts Inc.
**
**	This program is free software: you can redistribute it and/or modify
**	it under the terms of the GNU General Public License as published by
**	the Free Software Foundation, either version 3 of the License, or
**	(at your option) any later version.
**
**	This program is distributed in the hope that it will be useful,
**	but WITHOUT ANY WARRANTY; without even the implied warranty of
**	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**	GNU General Public License for more details.
**
**	You should have received a copy of the GNU General Public License
**	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

////////////////////////////////////////////////////////////////////////////////
//																																						//
//  (c) 2001-2003 Electronic Arts Inc.																				//
//																																						//
////////////////////////////////////////////////////////////////////////////////

// FILE: MultiplayerSettings.h /////////////////////////////////////////////////////////////////////////////
// Settings common to multiplayer games
// Author: Matthew D. Campbell, January 2002
///////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "GameClient/Color.h"
#include "Common/Money.h"

// FORWARD DECLARATIONS ///////////////////////////////////////////////////////////////////////////
struct FieldParse;
class MultiplayerSettings;

// PUBLIC /////////////////////////////////////////////////////////////////////////////////////////

class MultiplayerColorDefinition
{
public:
	MultiplayerColorDefinition();
	//-----------------------------------------------------------------------------------------------
	static const FieldParse m_colorFieldParseTable[];		///< the parse table for INI definition
	const FieldParse *getFieldParse() const { return m_colorFieldParseTable; }

	AsciiString getTooltipName() const { return m_tooltipName; };
	RGBColor getRGBValue() const { return m_rgbValue; };
	RGBColor getRGBNightValue() const { return m_rgbValueNight; };
	Color getColor() const { return m_color; }
	Color getNightColor() const { return m_colorNight; }
	void setColor( RGBColor rgb );
	void setNightColor( RGBColor rgb );

	MultiplayerColorDefinition * operator =(const MultiplayerColorDefinition& other);

private:
	AsciiString m_tooltipName;	///< tooltip name for color combo box (AsciiString to pass to TheGameText->fetch())
	RGBColor m_rgbValue;						///< RGB color value
	Color m_color;
	RGBColor m_rgbValueNight;						///< RGB color value
	Color m_colorNight;
};

typedef std::map<Int, MultiplayerColorDefinition> MultiplayerColorList;
typedef std::map<Int, MultiplayerColorDefinition>::iterator MultiplayerColorIter;

// A list of values to display in the starting money dropdown
typedef std::vector< Money > MultiplayerStartingMoneyList;

//-------------------------------------------------------------------------------------------------
/** Multiplayer Settings container class
  *	Defines multiplayer settings */
//-------------------------------------------------------------------------------------------------
class MultiplayerSettings : public SubsystemInterface
{
public:

	MultiplayerSettings();

	virtual void init() override { }
	virtual void update() override { }
	virtual void reset() override { }

	//-----------------------------------------------------------------------------------------------
	static const FieldParse m_multiplayerSettingsFieldParseTable[];		///< the parse table for INI definition
	const FieldParse *getFieldParse() const { return m_multiplayerSettingsFieldParseTable; }

	// Color management --------------------
	MultiplayerColorDefinition * findMultiplayerColorDefinitionByName(AsciiString name);
	MultiplayerColorDefinition * newMultiplayerColorDefinition(AsciiString name);

	Int getStartCountdownTimerSeconds() { return m_startCountdownTimerSeconds; }
	Int getMaxBeaconsPerPlayer() { return m_maxBeaconsPerPlayer; }
	Bool isShroudInMultiplayer() { return m_isShroudInMultiplayer; }
	Bool showRandomPlayerTemplate() { return m_showRandomPlayerTemplate; }
	Bool showRandomStartPos() { return m_showRandomStartPos; }
	Bool showRandomColor() { return m_showRandomColor; }

	Int getNumColors()
	{
		if (m_numColors == 0) {
			m_numColors = m_colorList.size();
		}
		return m_numColors;
	}
	MultiplayerColorDefinition * getColor(Int which);


  const Money & getDefaultStartingMoney() const
  {
    DEBUG_ASSERTCRASH( m_gotDefaultStartingMoney, ("You must specify a default starting money amount in multiplayer.ini") );
    return m_defaultStartingMoney;
  }

  const MultiplayerStartingMoneyList & getStartingMoneyList() const { return m_startingMoneyList; }

  void addStartingMoneyChoice( const Money & money, Bool isDefault );

private:
	Int m_initialCreditsMin;
	Int m_initialCreditsMax;
	Int m_startCountdownTimerSeconds;
	Int m_maxBeaconsPerPlayer;
	Bool m_isShroudInMultiplayer;
	Bool m_showRandomPlayerTemplate;
	Bool m_showRandomStartPos;
	Bool m_showRandomColor;

	MultiplayerColorList m_colorList;
	Int m_numColors;
	MultiplayerColorDefinition m_observerColor;
	MultiplayerColorDefinition m_randomColor;
  MultiplayerStartingMoneyList      m_startingMoneyList;
  Money                             m_defaultStartingMoney;
  Bool                              m_gotDefaultStartingMoney;
};

// singleton
extern MultiplayerSettings *TheMultiplayerSettings;
