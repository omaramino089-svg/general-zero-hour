/*
**	Command & Conquer Generals Zero Hour(tm)
**	Copyright 2025 Electronic Arts Inc.
**
**	This program is free software: you can redistribute it and/or modify
**	it under the terms of the GNU General Public License as published by
**	the Free Software Foundation, either version 3 of the License, or
**	(at your option) any later version.
**
**	This program is distributed in the hope that it will be useful,
**	but WITHOUT ANY WARRANTY; without even the implied warranty of
**	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**	GNU General Public License for more details.
**
**	You should have received a copy of the GNU General Public License
**	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

////////////////////////////////////////////////////////////////////////////////
//																																						//
//  (c) 2001-2003 Electronic Arts Inc.																				//
//																																						//
////////////////////////////////////////////////////////////////////////////////

// This file contains all the header files that shouldn't change frequently.
// Be careful what you stick in here, because putting files that change often in here will
// tend to cheese people's goats.

#pragma once

//-----------------------------------------------------------------------------
// srj sez: this must come first, first, first.
#define _STLP_USE_NEWALLOC					1
//#define _STLP_USE_CUSTOM_NEWALLOC		STLSpecialAlloc
class STLSpecialAlloc;


// We actually don't use Windows for much other than timeGetTime, but it was included in 40
// different .cpp files, so I bit the bullet and included it here.
// PLEASE DO NOT ABUSE WINDOWS OR IT WILL BE REMOVED ENTIRELY. :-)
//--------------------------------------------------------------------------------- System Includes
#ifdef _WIN32
    #define WIN32_LEAN_AND_MEAN
    // TheSuperHackers @build JohnsterID 05/01/2026 Add ATL compatibility for MinGW-w64 builds
    #if defined(__GNUC__)
        #include <Utility/atl_compat.h>
    #endif
    #include <atlbase.h>
    #include <windows.h>
#else
    // GeneralsX @build BenderAI 09/02/2026 Linux compatibility - Windows API stubs
    #include "windows_compat.h"
#endif

// Platform compatibility
#include <Utility/intrin_compat.h>

#include <assert.h>
#include <ctype.h>
#ifdef _WIN32
    #include <direct.h>
    #include <excpt.h>
#endif
#include <float.h>
#include <Utility/fstream_adapter.h>
#ifdef _WIN32
    #include <imagehlp.h>
    #include <io.h>
    #include <lmcons.h>
#endif
#if defined(_MSC_VER) && _MSC_VER < 1300
    #include <mapicode.h>
#endif
#include <math.h>
#include <memory.h>
#ifdef _WIN32
    #include <mmsystem.h>
    #include <objbase.h>
    #include <ocidl.h>
    #include <process.h>
    #include <shellapi.h>
    #include <shlobj.h>
    #include <shlguid.h>
    #include <snmp.h>
#endif
#include <stdarg.h>
#include <stddef.h>
#include <stdlib.h>
#include <sys/stat.h>
#ifdef _WIN32
    #include <sys/timeb.h>
#endif
#include <sys/types.h>
#ifdef _WIN32
    #include <tchar.h>
#endif
#include <time.h>
#ifdef _WIN32
    #include <vfw.h>
    #include <winerror.h>
    #include <wininet.h>
    #include <winreg.h>
#endif

#ifdef _WIN32
    #ifndef DIRECTINPUT_VERSION
        #define DIRECTINPUT_VERSION	0x800
    #endif
    #include <dinput.h>
#endif

//------------------------------------------------------------------------------------ STL Includes
// srj sez: no, include STLTypesdefs below, instead, thanks
//#include <algorithm>
//#include <bitset>
//#include <hash_map>
//#include <list>
//#include <map>
//#include <queue>
//#include <set>
//#include <stack>
//#include <string>
//#include <vector>

//------------------------------------------------------------------------------------ RTS Includes
// Icky. These have to be in this order.
#include "Lib/BaseType.h"
#include "Common/STLTypedefs.h"
#include "Common/Errors.h"
#include "Common/Debug.h"
#include "Common/AsciiString.h"
#include "Common/SubsystemInterface.h"

#include "Common/GameCommon.h"
#include "Common/GameMemory.h"
#include "Common/GameType.h"
#include "Common/GlobalData.h"

// You might not want Kindof in here because it seems like it changes frequently, but the problem
// is that Kindof is included EVERYWHERE, so it might as well be precompiled.
#include "Common/INI.h"
#include "Common/KindOf.h"
#include "Common/DisabledTypes.h"
#include "Common/NameKeyGenerator.h"
#include "GameClient/ClientRandomValue.h"
#include "GameLogic/LogicRandomValue.h"
#include "Common/ObjectStatusTypes.h"

#include "Common/Thing.h"
#include "Common/UnicodeString.h"

#if defined(__GNUC__) && defined(_WIN32)
    #pragma GCC diagnostic pop
#endif
