/*
**	Command & Conquer Renegade(tm)
**	Copyright 2025 Electronic Arts Inc.
**
**	This program is free software: you can redistribute it and/or modify
**	it under the terms of the GNU General Public License as published by
**	the Free Software Foundation, either version 3 of the License, or
**	(at your option) any later version.
**
**	This program is distributed in the hope that it will be useful,
**	but WITHOUT ANY WARRANTY; without even the implied warranty of
**	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**	GNU General Public License for more details.
**
**	You should have received a copy of the GNU General Public License
**	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once

// AnimMixingPage.h : header file
//

class CAdvancedAnimSheet;

/////////////////////////////////////////////////////////////////////////////
// CAnimMixingPage dialog

class CAnimMixingPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CAnimMixingPage)

// Construction
public:
	CAnimMixingPage(CAdvancedAnimSheet *sheet = nullptr);
	~CAnimMixingPage();

// Dialog Data
	//{{AFX_DATA(CAnimMixingPage)
	enum { IDD = IDD_PROP_PAGE_ADVANIM_MIXING };
	CListCtrl	m_AnimList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAnimMixingPage)
	public:
	virtual void OnOK() override;
	virtual BOOL OnKillActive() override;
	protected:
	virtual void DoDataExchange(CDataExchange* pDX) override;    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	void FillListCtrl ();

	CAdvancedAnimSheet *m_Sheet;

	// Generated message map functions
	//{{AFX_MSG(CAnimMixingPage)
	virtual BOOL OnInitDialog() override;
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
