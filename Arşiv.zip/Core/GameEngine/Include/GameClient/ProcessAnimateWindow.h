/*
**	Command & Conquer Generals Zero Hour(tm)
**	Copyright 2025 Electronic Arts Inc.
**
**	This program is free software: you can redistribute it and/or modify
**	it under the terms of the GNU General Public License as published by
**	the Free Software Foundation, either version 3 of the License, or
**	(at your option) any later version.
**
**	This program is distributed in the hope that it will be useful,
**	but WITHOUT ANY WARRANTY; without even the implied warranty of
**	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**	GNU General Public License for more details.
**
**	You should have received a copy of the GNU General Public License
**	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

////////////////////////////////////////////////////////////////////////////////
//																																						//
//  (c) 2001-2003 Electronic Arts Inc.																				//
//																																						//
////////////////////////////////////////////////////////////////////////////////

// FILE: ProcessAnimateWindow.h /////////////////////////////////////////////////
//-----------------------------------------------------------------------------
//
//                       Electronic Arts Pacific.
//
//                       Confidential Information
//                Copyright (C) 2002 - All Rights Reserved
//
//-----------------------------------------------------------------------------
//
//	created:	Mar 2002
//
//	Filename: 	ProcessAnimateWindow.h
//
//	author:		Chris Huybregts
//
//	purpose:	If a new animation is wanted to be added for the windows, All you
//						have to do is create a new class derived from ProcessAnimateWindow.
//						Then setup each of the virtual classes to process an AnimateWindow
//						class.  The Update and reverse functions get called every frame
//						by the shell and will continue to process the AdminWin until the
//						isFinished flag on the adminWin is set to true.
//
//-----------------------------------------------------------------------------
///////////////////////////////////////////////////////////////////////////////

#pragma once

//-----------------------------------------------------------------------------
// SYSTEM INCLUDES ////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// USER INCLUDES //////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
#include "Lib/BaseType.h"
//-----------------------------------------------------------------------------
// FORWARD REFERENCES /////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
namespace wnd
{
class AnimateWindow;
}
class GameWindow;
//-----------------------------------------------------------------------------
// TYPE DEFINES ///////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
class ProcessAnimateWindow
{
public:

	ProcessAnimateWindow(){};
	virtual ~ProcessAnimateWindow(){};

	virtual void initAnimateWindow( wnd::AnimateWindow *animWin ) = 0;
	virtual void initReverseAnimateWindow( wnd::AnimateWindow *animWin, UnsignedInt maxDelay = 0 ) = 0;
	virtual Bool updateAnimateWindow( wnd::AnimateWindow *animWin ) = 0;
	virtual Bool reverseAnimateWindow( wnd::AnimateWindow *animWin ) = 0;
	virtual void setMaxDuration(UnsignedInt maxDuration) { }
};

//-----------------------------------------------------------------------------

class ProcessAnimateWindowSlideFromRight : public ProcessAnimateWindow
{
public:

	ProcessAnimateWindowSlideFromRight();
	virtual ~ProcessAnimateWindowSlideFromRight() override;

	virtual void initAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual void initReverseAnimateWindow( wnd::AnimateWindow *animWin, UnsignedInt maxDelay = 0 ) override;
	virtual Bool updateAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual Bool reverseAnimateWindow( wnd::AnimateWindow *animWin ) override;
private:
Coord2D m_maxVel;  // top speed windows travel in x and y
Int m_slowDownThreshold;  // when windows get this close to their resting
																		// positions they start to slow down
Real m_slowDownRatio;  // how fast the windows slow down (smaller slows quicker)
Real m_speedUpRatio;  // how fast the windows speed up

};


//-----------------------------------------------------------------------------

class ProcessAnimateWindowSlideFromLeft : public ProcessAnimateWindow
{
public:

	ProcessAnimateWindowSlideFromLeft();
	virtual ~ProcessAnimateWindowSlideFromLeft() override;

	virtual void initAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual void initReverseAnimateWindow( wnd::AnimateWindow *animWin, UnsignedInt maxDelay = 0 ) override;
	virtual Bool updateAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual Bool reverseAnimateWindow( wnd::AnimateWindow *animWin ) override;
private:
Coord2D m_maxVel;  // top speed windows travel in x and y
Int m_slowDownThreshold;  // when windows get this close to their resting
																		// positions they start to slow down
Real m_slowDownRatio;  // how fast the windows slow down (smaller slows quicker)
Real m_speedUpRatio;  // how fast the windows speed up

};


//-----------------------------------------------------------------------------

class ProcessAnimateWindowSlideFromTop : public ProcessAnimateWindow
{
public:

	ProcessAnimateWindowSlideFromTop();
	virtual ~ProcessAnimateWindowSlideFromTop() override;

	virtual void initAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual void initReverseAnimateWindow( wnd::AnimateWindow *animWin, UnsignedInt maxDelay = 0 ) override;
	virtual Bool updateAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual Bool reverseAnimateWindow( wnd::AnimateWindow *animWin ) override;
private:
Coord2D m_maxVel;  // top speed windows travel in x and y
Int m_slowDownThreshold;  // when windows get this close to their resting
																		// positions they start to slow down
Real m_slowDownRatio;  // how fast the windows slow down (smaller slows quicker)
Real m_speedUpRatio;  // how fast the windows speed up

};

//-----------------------------------------------------------------------------
class ProcessAnimateWindowSlideFromTopFast : public ProcessAnimateWindow
{
public:

	ProcessAnimateWindowSlideFromTopFast();
	virtual ~ProcessAnimateWindowSlideFromTopFast() override;

	virtual void initAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual void initReverseAnimateWindow( wnd::AnimateWindow *animWin, UnsignedInt maxDelay = 0 ) override;
	virtual Bool updateAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual Bool reverseAnimateWindow( wnd::AnimateWindow *animWin ) override;
private:
Coord2D m_maxVel;  // top speed windows travel in x and y
Int m_slowDownThreshold;  // when windows get this close to their resting
																		// positions they start to slow down
Real m_slowDownRatio;  // how fast the windows slow down (smaller slows quicker)
Real m_speedUpRatio;  // how fast the windows speed up

};


//-----------------------------------------------------------------------------

class ProcessAnimateWindowSlideFromBottom : public ProcessAnimateWindow
{
public:

	ProcessAnimateWindowSlideFromBottom();
	virtual ~ProcessAnimateWindowSlideFromBottom() override;

	virtual void initAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual void initReverseAnimateWindow( wnd::AnimateWindow *animWin, UnsignedInt maxDelay = 0 ) override;
	virtual Bool updateAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual Bool reverseAnimateWindow( wnd::AnimateWindow *animWin ) override;
private:
Coord2D m_maxVel;  // top speed windows travel in x and y
Int m_slowDownThreshold;  // when windows get this close to their resting
																		// positions they start to slow down
Real m_slowDownRatio;  // how fast the windows slow down (smaller slows quicker)
Real m_speedUpRatio;  // how fast the windows speed up

};

//-----------------------------------------------------------------------------

class ProcessAnimateWindowSpiral : public ProcessAnimateWindow
{
public:

	ProcessAnimateWindowSpiral();
	virtual ~ProcessAnimateWindowSpiral() override;

	virtual void initAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual void initReverseAnimateWindow( wnd::AnimateWindow *animWin, UnsignedInt maxDelay = 0 ) override;
	virtual Bool updateAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual Bool reverseAnimateWindow( wnd::AnimateWindow *animWin ) override;
private:
	Real m_deltaTheta;
	Int m_maxR;
};

//-----------------------------------------------------------------------------

class ProcessAnimateWindowSlideFromBottomTimed : public ProcessAnimateWindow
{
public:

	ProcessAnimateWindowSlideFromBottomTimed();
	virtual ~ProcessAnimateWindowSlideFromBottomTimed() override;

	virtual void initAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual void initReverseAnimateWindow( wnd::AnimateWindow *animWin, UnsignedInt maxDelay = 0 ) override;
	virtual Bool updateAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual Bool reverseAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual void setMaxDuration(UnsignedInt maxDuration) override { m_maxDuration = maxDuration; }

private:
	UnsignedInt m_maxDuration;

};

class ProcessAnimateWindowSlideFromRightFast : public ProcessAnimateWindow
{
public:

	ProcessAnimateWindowSlideFromRightFast();
	virtual ~ProcessAnimateWindowSlideFromRightFast() override;

	virtual void initAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual void initReverseAnimateWindow( wnd::AnimateWindow *animWin, UnsignedInt maxDelay = 0 ) override;
	virtual Bool updateAnimateWindow( wnd::AnimateWindow *animWin ) override;
	virtual Bool reverseAnimateWindow( wnd::AnimateWindow *animWin ) override;
private:
Coord2D m_maxVel;  // top speed windows travel in x and y
Int m_slowDownThreshold;  // when windows get this close to their resting
																		// positions they start to slow down
Real m_slowDownRatio;  // how fast the windows slow down (smaller slows quicker)
Real m_speedUpRatio;  // how fast the windows speed up

};


//-----------------------------------------------------------------------------
// INLINING ///////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// EXTERNALS //////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
